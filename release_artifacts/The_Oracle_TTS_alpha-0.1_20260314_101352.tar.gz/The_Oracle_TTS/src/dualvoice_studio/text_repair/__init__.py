"""Text repair pipeline components."""
